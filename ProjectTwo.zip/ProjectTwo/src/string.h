/*
 * string.h
 *
 *  Created on: Feb 23, 2026
 *      Author: Administrator
 */

#ifndef STRING_H_
#define STRING_H_

class string {
public:
	string();
	virtual ~string();
};

#endif /* STRING_H_ */
