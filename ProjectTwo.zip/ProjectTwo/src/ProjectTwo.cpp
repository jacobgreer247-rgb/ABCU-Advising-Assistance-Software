//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Jacob Greer
// Version     :
// Copyright   : Your copyright notice
// Description : Course Planner App
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <set>
#include <cctype>
#include <limits>

using namespace std;

struct Course {
    string courseNumber;
    string title;
    vector<string> prerequisites;
};

static string Trim(const string& s) {
    size_t start = 0;
    while (start < s.size() && isspace(static_cast<unsigned char>(s[start]))) start++;
    size_t end = s.size();
    while (end > start && isspace(static_cast<unsigned char>(s[end - 1]))) end--;
    return s.substr(start, end - start);
}

static string ToUpperString(string s) {
    for (char& ch : s) {
        ch = static_cast<char>(toupper(static_cast<unsigned char>(ch)));
    }
    return s;
}

class CourseBST {
private:
    struct Node {
        Course course;
        Node* left;
        Node* right;
        Node(const Course& c) : course(c), left(nullptr), right(nullptr) {}
    };

    Node* root;

    Node* Insert(Node* node, const Course& course) {
        if (node == nullptr) {
            return new Node(course);
        }
        if (course.courseNumber < node->course.courseNumber) {
            node->left = Insert(node->left, course);
        }
        else if (course.courseNumber > node->course.courseNumber) {
            node->right = Insert(node->right, course);
        }
        else {
            node->course = course;
        }
        return node;
    }

    Node* Search(Node* node, const string& courseNumber) const {
        if (node == nullptr) return nullptr;
        if (courseNumber == node->course.courseNumber) return node;
        if (courseNumber < node->course.courseNumber) {
            return Search(node->left, courseNumber);
        }
        return Search(node->right, courseNumber);
    }

    void InOrderPrint(Node* node) const {
        if (node == nullptr) return;
        InOrderPrint(node->left);
        cout << node->course.courseNumber << ", " << node->course.title << endl;
        InOrderPrint(node->right);
    }

    void Destroy(Node* node) {
        if (node == nullptr) return;
        Destroy(node->left);
        Destroy(node->right);
        delete node;
    }

public:
    CourseBST() : root(nullptr) {}
    ~CourseBST() { Clear(); }

    void Clear() {
        Destroy(root);
        root = nullptr;
    }

    void Insert(const Course& course) {
        root = Insert(root, course);
    }

    Course* GetCourse(const string& courseNumber) const {
        Node* node = Search(root, courseNumber);
        if (node == nullptr) return nullptr;
        return &(node->course);
    }

    void PrintSortedList() const {
        InOrderPrint(root);
    }
};

static vector<string> SplitCSVLine(const string& line) {
    vector<string> tokens;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        tokens.push_back(Trim(token));
    }
    return tokens;
}

static bool LoadCoursesFromFile(const string& filename, CourseBST& bst) {
    ifstream file(filename); // @suppress("Invalid arguments")
    if (!file.is_open()) {
        cout << "Error opening file." << endl;
        return false;
    }

    bst.Clear();
    set<string> courseNumbers;
    vector<Course> tempCourses;
    string line;

    while (getline(file, line)) {
        if (Trim(line).empty()) continue;

        vector<string> values = SplitCSVLine(line);
        if (values.size() < 2) {
            cout << "Format error in file." << endl;
            return false;
        }

        Course c;
        c.courseNumber = ToUpperString(values[0]);
        c.title = values[1];
        courseNumbers.insert(c.courseNumber); // @suppress("Method cannot be resolved")

        for (size_t i = 2; i < values.size(); i++) {
            string prereq = ToUpperString(values[i]);
            if (!prereq.empty()) {
                c.prerequisites.push_back(prereq);
            }
        }

        tempCourses.push_back(c);
    }

    for (const Course& c : tempCourses) {
        for (const string& prereq : c.prerequisites) {
            if (courseNumbers.find(prereq) == courseNumbers.end()) {
                cout << "Prerequisite error found." << endl;
                return false;
            }
        }
    }

    for (const Course& c : tempCourses) {
        bst.Insert(c);
    }

    cout << "Data loaded successfully." << endl;
    return true;
}

static void PrintMenu() {
    cout << endl;
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
}

static void PrintCourseInfo(const CourseBST& bst, const string& input) {
    string courseNum = ToUpperString(Trim(input));
    Course* course = bst.GetCourse(courseNum);

    if (course == nullptr) {
        cout << "Course not found." << endl;
        return;
    }

    cout << course->courseNumber << ", " << course->title << endl;

    if (course->prerequisites.empty()) {
        cout << "Prerequisites: None" << endl;
        return;
    }

    cout << "Prerequisites:" << endl;
    for (const string& prereqNum : course->prerequisites) {
        Course* prereq = bst.GetCourse(prereqNum);
        if (prereq != nullptr) {
            cout << prereq->courseNumber << ", " << prereq->title << endl;
        }
        else {
            cout << prereqNum << endl;
        }
    }
}

int main() {
    CourseBST bst;
    bool loaded = false;

    cout << "Welcome to the course planner." << endl;

    int choice = 0;
    while (choice != 9) {
        PrintMenu();
        cout << "What would you like to do? ";

        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "That is not a valid option." << endl;
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1) {
            cout << "Enter the file name: ";
            string filename;
            getline(cin, filename);
            loaded = LoadCoursesFromFile(filename, bst);
        }
        else if (choice == 2) {
            if (!loaded) {
                cout << "Please load data first." << endl;
            }
            else {
                cout << "Here is a sample schedule:" << endl;
                bst.PrintSortedList();
            }
        }
        else if (choice == 3) {
            if (!loaded) {
                cout << "Please load data first." << endl;
            }
            else {
                cout << "What course do you want to know about? ";
                string courseNum;
                getline(cin, courseNum);
                PrintCourseInfo(bst, courseNum);
            }
        }
        else if (choice == 9) {
            cout << "Thank you for using the course planner" << endl;
        }
        else {
            cout << choice << " is not a valid option." << endl;
        }
    }

    return 0;
}
